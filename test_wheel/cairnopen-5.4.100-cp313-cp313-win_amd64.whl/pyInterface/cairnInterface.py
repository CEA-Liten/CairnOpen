import os
import sys
import glob
import copy
import re
from re import X

import pandas as pd
from cairn import CairnAPI, OptimProblem

def set_param(problem, header_col, value):
    try:
        component=problem.get_component(header_col[0])
        print(header_col[1])
        if "--" in header_col[1]:
            port = component.get_port(header_col[1].split("--")[0])
            port.set_setting_value(header_col[1].split("--")[1],value)
            old_value = port.get_setting_value(header_col[1].split("--")[1])
        else:
            old_value = component.get_setting_value(header_col[1])
            component.set_setting_value(header_col[1], value)
        return(header_col[0],header_col[1],old_value)
    except RuntimeError:
        try:
            energy_carrier=problem.get_energy_carrier(header_col[0])
            old_value = energy_carrier.get_setting_value(header_col[1])
            energy_carrier.set_setting_value(header_col[1], value)
            return(header_col[0],header_col[1],old_value)
        except RuntimeError:
            try:
                bus = problem.get_bus(header_col[0])
                old_value = bus.get_setting_value(header_col[1])
                bus.set_setting_value(header_col[1], value)
                return(header_col[0],header_col[1],old_value)
            except RuntimeError:
                try:
                    tech_eco = problem.get_tech_eco_analysis()
                    old_value = tech_eco.get_setting_value(header_col[1])
                    tech_eco.set_setting_value(header_col[1], value)
                    return(header_col[0],header_col[1],old_value)
                except RuntimeError:
                    try:
                        solver = problem.get_solver()
                        old_value = solver.get_setting_value(header_col[1])
                        solver.set_setting_value(header_col[1], value)                        
                        return(header_col[0],header_col[1],old_value)
                    except RuntimeError:
                        try:
                            simulation_control = problem.get_simulation_control()
                            old_value = simulation_control.get_setting_value(header_col[1])
                            simulation_control.set_setting_value(header_col[1], value) 
                            return(header_col[0],header_col[1],old_value)
                        except RuntimeError:
                            assert False, "Component "+ header_col[0]+" or parameter "+header_col[1]+" not found"

def get_element(problem,name):
    """
    Get any component (bus,energy vector or component) by its name.
    If no component is found , return the problem
    """
    try:
        compo = problem.get_component(name)
        return compo
    except RuntimeError:
        try:
            bus = problem.get_bus(name)
            return bus
        except RuntimeError:
            try:
                energy_carrier = problem.get_energy_carrier(name)
                return energy_carrier
            except RuntimeError:
                tecEco = problem.get_tech_eco_analysis()
                return tecEco
                        

def run_sensitivity(problem, df_sens, max_time=-1,indicators = pd.DataFrame()):
    """ runs sensitivity study of a given problem with a given input dataframe (2 header rows: 1st row: name of the component, 
    2nd row: name of the parameter and one sensitivity study per row) for an optional maximal duration of each run.
    arg1: cairn problem
    arg2: dataframe containing sensitivity studies to be conducted
    arg3: maximal duration of each sensitivity study (optional)
    arg4: pandas dataframe of two colums Model and Indicator of KPI to save during sensitivity (file PLAN)
    :meta public:
    """
    columns=df_sens.columns.tolist()
    cases=df_sens.index.tolist()

    samplings = []
    for case in cases:
        sampling = [ {"Case":case}]
        for col in columns:
            setting = {"model":col[0], "value":df_sens[col][case]}
            if "--" in col[1]:
                setting["property"] = col[1].split("--")[1]
                setting["port"] = col[1].split("--")[0]
            else:
                setting["property"] = col[1]
            sampling.append(setting)
        samplings.append(sampling)

    if indicators.equals(pd.DataFrame()):
        res = problem.run_sensitivity(samplings, max_time, [])
    else:       
        indicators_list = [ {"model":indicators["Model"].iloc[i], "indicator": indicators["Indicator"].iloc[i]} for i in indicators.index]
        res = problem.run_sensitivity(samplings, max_time, indicators_list)

    if len(res)>0:        
        opt=pd.DataFrame()
        for caseRes in res:            
            opt = pd.concat([pd.DataFrame([caseRes]),opt], ignore_index=True)
    else:
            opt=pd.DataFrame()

    return opt

        

def copy_component(problem, component,new_name,connexions = True):
    """
    Make a copy of a component, with its parameters and connexions (optional).

    Parameters
    -------------
    problem: cairn.OptimProblem
        The problem that will be modified
    component: str
        The name of component to duplicate
    new_name: str
        The name of the duplicated component
    connexions: bool
        If true, the ports and links are also duplicated. 

    Returns
    ------------
    compo2: cairn.Component
        The new component.
    """
    compo = problem.get_component(component)
    compo2 = problem.create_component(new_name,compo.model_class)
    #copy carriers and settings of the default ports
    for p in compo.ports:  # loop on all ports to copy the settings of the default ports
        port = compo.get_port(p)
        carrier = problem.get_energy_carrier(port.carrier_name)
        if p in compo2.ports:  # if the port is a default port
            port2 = compo2.get_port(p)
            port2.set_carrier(carrier)
            port2.setting_values = port.setting_values
    #copy parameter values
    compo2.setting_values=compo.setting_values
    #copy labels 
    compo2.label_values=compo.label_values
    if connexions == True:
        for p in compo.ports:  # loop on all ports
            port = compo.get_port(p)
            carrier = problem.get_energy_carrier(port.carrier_name)
            if p not in compo2.ports:  # if the port is not a default port
                #add non-default ports and copy the settings 
                port2 = compo2.add_port(p, carrier)
                port2.setting_values = port.setting_values
            else:
                port2 = compo2.get_port(p)
            for l in problem.links:  # loop on links to add the same to the component (for all ports)
                compo_name_link = ".".join(l.split('.')[:-1])
                if compo_name_link == component and l.split('.')[-1]==port.name:
                    problem.add_link(port2,problem.get_bus(problem.links[l]))
    return compo2


def PasteResultsMonoLoc(projects_path, prefix, hist_plan, scenario_list=[],
                        lines_to_delete=["no data computed", "save iteration"], file_out="SUMUPALL.csv", list_order=[]):
    """
    Parameters
    ----------
    projects_path : str
        path of the project.
    scenarioList : list
        list of scenario names (when len < 2 the consider all scenario)
    prefix : str
        Beginning name of the case name (scenario).

    Returns
    -------
    Write the files SUMUP_configCase in which plan file are gathered to be compared.
    """

    PasteFile = os.path.join(projects_path,file_out)

    list_report, all_filenames = generate_report_list(projects_path, prefix, scenario_list, hist_plan + '.csv')

    # Re-order reports in case of run sensitivity for result sumupall_sens.csv file
    list_report, all_filenames = re_order_based_on_list(list_report, all_filenames, list_order)

    print("Reading results :", list_report, 'in', all_filenames)

    def import_sumup():
        try:
            perf_data = [pd.read_csv(f, sep=";", header=None, usecols=[0, 1, 2], on_bad_lines='warn', encoding="utf-8")
                         for f in all_filenames]
        except UnicodeDecodeError:
            perf_data = [
                pd.read_csv(f, sep=";", header=None, usecols=[0, 1, 2], on_bad_lines='warn', encoding="ISO-8859-1") for
                f in all_filenames]
        for i in range(len(perf_data)):
            perf_data[i].dropna(how="all", inplace=True)
            # for j in range(len(perf_data[i][0])):
            ndc = perf_data[i][1].str.contains("no data computed").index
            perf_data[i].drop(ndc)
            perf_data[i]["Component.Variable"] = perf_data[i][0] + "." + perf_data[i][1]
            for li in lines_to_delete:
                ndc = perf_data[i][perf_data[i]["Component.Variable"].str.contains(li)].index
            perf_data[i] = perf_data[i].drop(ndc)
            perf_data[i] = perf_data[i].set_index("Component.Variable")
            perf_data[i] = perf_data[i].rename(columns={2: list_report[i]})
            del perf_data[i][0]
            del perf_data[i][1]
        return perf_data

    def sumup_file():
        tab = import_sumup()
        try:
            sumup = tab[0]
            for i in range(1, len(tab)):
                sumup = sumup.join(tab[i], how='inner')
            return sumup
        except IndexError:
            print("Issue in sumup file, no run produced results")

    sumup = sumup_file()
    sumup.to_csv(PasteFile, sep=';', encoding="utf-8")
    return sumup

def generate_report_list(projects_path, prefix, scenario_list, file_ext):
    all_filenames = []
    list_report = []
    if len(scenario_list) < 2:
        scenario = prefix
        if len(scenario_list) == 1:
            scenario = scenario + '_' + scenario_list[0]
        #check inside all folders starts with scenario
        strs = os.path.join(projects_path,scenario+'*', '*'+file_ext)
        print("Looking for a match to ", strs)
        if file_ext == '.json':
            all_filenames = list(set([i.replace("_self","") for i in glob.glob(strs)]))
        else:
            all_filenames = list(set([i for i in glob.glob(strs)]))

        for f in range(len(all_filenames)):
            m = re.search(scenario + r'([\d _a-zA-Z]+)', all_filenames[f])
            if type(m) is not type(None):
                matchTest = m.group()
                list_report.append(matchTest)
            elif len(scenario_list) == 1:
                m = re.search(scenario , all_filenames[f])
                if type(m) is not type(None):
                    list_report.append(scenario)
    else:#multiple scenario names are given
        for name in scenario_list:
            scenario = prefix + '_' + name
            #check only exact scenario folder
            strs = os.path.join(projects_path,scenario,'*'+file_ext)
            print("Looking for a match to ", strs)
            if file_ext == '.json':
                tmp_filenames = list(set([i.replace("_self","") for i in glob.glob(strs)]))
            else:
                tmp_filenames = list(set([i  for i in glob.glob(strs)]))
            if tmp_filenames:
                all_filenames.extend(tmp_filenames)
                list_report.append(scenario)
    return list_report, all_filenames

def re_order_based_on_list(list_report, all_filenames, list_order):
    #Re-order list_report and all_filenames based on the order set in list_order
    ordered_reports, ordered_filenames = [], []
    other_reports = copy.deepcopy(list_report)
    other_filenames = copy.deepcopy(all_filenames)

    #Order matched file in the same order as appears in list_order
    for element in list_order:
        for report in list_report:
            if report == "Report_s"+element or report == element:
                ordered_reports.append(report)
                i_report = list_report.index(report)
                ordered_filenames.append(all_filenames[i_report])

    #Obtain the remaining reports
    for report in list_report:
        if report in ordered_reports:
            i_report = other_reports.index(report)
            other_reports.pop(i_report)
            other_filenames.pop(i_report)

    # Use alphabetic order
    other_reports = sorted(other_reports)
    other_filenames = sorted(other_filenames)

    #merge lists
    ordered_reports.extend(other_reports)
    ordered_filenames.extend(other_filenames)

    if set(ordered_reports) == set(list_report) and set(ordered_filenames) == set(all_filenames):
        list_report = ordered_reports
        all_filenames = ordered_filenames

    return list_report, all_filenames

def add_df_timeseries(problem : OptimProblem, timeSeries : pd.DataFrame):
     '''
     timeSeries : DataFrame with an header of 4 rows of string
        - Names
        - Description
        - Unit
        - ??
        The next rows are the values
     One column is one timeSeries
     '''
     sizeValues = timeSeries.index.stop          
     for col in timeSeries.columns:
         values = []
         for row in range(4,sizeValues):
             values.append(timeSeries.values[row][col])
         ts = {"Name": timeSeries.values[0][col], "Unit": timeSeries.values[2][col], "Description": timeSeries.values[1][col], "Values": values}
         problem.add_onetimeseries(ts)
  
